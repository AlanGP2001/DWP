package mx.edu.uteq.idgs06.idgs06_02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Idgs0601ApplicationTests {

	@Test
	void contextLoads() {
	}

}
