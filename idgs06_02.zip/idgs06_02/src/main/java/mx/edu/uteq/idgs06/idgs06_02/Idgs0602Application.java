package mx.edu.uteq.idgs06.idgs06_02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Idgs0602Application {

	public static void main(String[] args) {
		SpringApplication.run(Idgs0602Application.class, args);
                System.out.println("inicio...");
	}

}
